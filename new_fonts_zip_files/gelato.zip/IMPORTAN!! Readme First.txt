NOTE: This font is FREE! But any donation is very appreciated. 

Paypal account for donation : 
https://paypal.me/alpaprana

Check Our Store: 
https://gumroad.com/alpaprana

For information please email:
alpapranastudio@gmail.com

Thank you :)

Best
Alpaprana