Thanks for downloading our font, This font is free for any personal or commercial use but any donation will be very appreciated..

Any questions? feel free to drop me a message : naufalanis14@gmail.com

Link to donation : www.paypal.me/masanis

Link to our other premium product : www.creativemarket.com/naufalans

Thanks,
MasAnis